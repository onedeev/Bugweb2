module.exports = {
  tokens: "8557655529:AAHTOcGb1Pf7uVNXlPx4fxcdddFy7jTSPpU",  // Ubah Jadi Token Bot Mu !!!
  owner: "8460744156", // Ubah Jadi Id Mu !!!
  port: "1466", // Ubah Jadi Port Panel Mu !!!
  ipvps: "167.172.64.240" // Ubah Jadi Ip Vps Mu !!!
};